Java.asJSONCompatible({
    animation: function (entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
        var flight1 = modelMap.get("flight1")
        var flight2 = modelMap.get("flight2")
        var propeller1 = modelMap.get("propeller1")
        var propeller2 = modelMap.get("propeller2")
        var propeller3 = modelMap.get("propeller3")
        var propeller4 = modelMap.get("propeller4")

        var time = ((ageInTicks * 3.6) % 360) * 0.017453292;
        if (flight1 != undefined) {
            flight1.setRotateAngleY(-time)
        }
        if (flight2 != undefined) {
            flight2.setRotateAngleY(time)
        }
        if (propeller1 != undefined) {
            propeller1.setRotateAngleZ(time * 10)
        }
        if (propeller2 != undefined) {
            propeller2.setRotateAngleZ(time * 10)
        }
        if (propeller3 != undefined) {
            propeller3.setRotateAngleZ(time * 10)
        }
        if (propeller4 != undefined) {
            propeller4.setRotateAngleZ(time * 10)
        }
    }
})