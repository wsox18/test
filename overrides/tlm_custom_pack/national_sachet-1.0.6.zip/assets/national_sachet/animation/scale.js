var GlWrapper = Java.type("com.github.tartaricacid.touhoulittlemaid.client.animation.script.GlWrapper");

Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
        GlWrapper.scale(1.5, 1.5, 1.5)
        GlWrapper.translate(0, -0.5, 0)
    }
})